import React from "react";
// import "./PageTitle.css";

const PageTitle = () => {
  return (
    <div className="page-title">
      <h1>State GIS Portal</h1>
    </div>
  );
};

export default PageTitle;
