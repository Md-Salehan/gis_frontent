
const defaultStyleLayerFeature = (feature, layer, dispatch) => {
  
};


const dynamicStyleLayerFeature = (feature, layer, dispatch) => {
  
};

export default defaultStyleLayerFeature;
