import L from 'leaflet';
import '@geoman-io/leaflet-geoman-free';

// This ensures geoman is available globally
export const initGeoman = () => {
  console.log('Geoman initialized globally');
};